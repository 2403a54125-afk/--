PROJECT: Market Price Prediction of Agriculture Products Using Regression

Overview

This project focuses on predicting the market price of agriculture products using a regression-based machine learning model.
The goal is to help farmers, traders, and market analysts estimate future prices based on factors such as product type, year, month, rainfall, and wholesale price index (WPI).

A simple Flask web application is used so that users can enter input values and immediately see the predicted price on a user-friendly webpage.

Project Structure

model.py – Contains the machine learning model, data preprocessing steps, and the prediction function.

app.py – Flask backend that connects the model with the webpage, receives user input, and returns the prediction.

templates/index.html – Frontend webpage where the user enters inputs and views the predicted price.


How It Works

1. The user opens the webpage.


2. Inputs details such as product name, year, month, rainfall, and WPI.


3. The Flask backend receives the data and passes it to the regression model.


4. The model predicts the expected price using historical data and regression logic.


5. The predicted price is displayed on the webpage.



Technologies Used

Python
Flask
Pandas
Scikit Learn
HTML

Files Description

model.py – Handles loading the data, preprocessing, building the regression model, and predicting prices.
app.py – Runs the Flask server, manages routes, and connects user inputs with the model.
index.html – Provides a simple and intuitive interface to input details and view results.

How to Run

1. Install the required Python libraries: Flask, Pandas, Scikit Learn.


2. Run the Flask application by executing app.py.


3. Open the local server link in a web browser.


4. Enter the product details and get the predicted market price.



Output

The application predicts the price of the selected agriculture product based on the given inputs. This helps users understand market trends and plan accordingly.